const $=s=>document.querySelector(s);
function show(id){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));$('#'+id).classList.add('active');document.querySelectorAll('nav button').forEach(x=>x.classList.remove('active'));if(id==='projects')loadProjects();}
async function generate(){
 const topic=$('#topic').value.trim(); if(!topic){$('#status').textContent='Give me a topic first 😄';return;}
 $('#status').textContent='Building your video plan…';
 const r=await fetch('/api/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({topic,style:$('#style').value,platform:$('#platform').value,duration:+$('#duration').value})});
 const p=await r.json(); if(p.error){$('#status').textContent=p.error;return;}
 $('#status').textContent='Plan created. Next step: render.';
 $('#result').innerHTML=`<div class="card" style="margin-top:20px"><h2>${esc(p.title)}</h2><p class="muted">${p.platform} · ${p.duration}s · ${p.scenes.length} scenes</p>${p.scenes.map((s,i)=>`<div class="scene"><h3>Scene ${i+1} · ${s.seconds}s</h3><p>${esc(s.narration)}</p><p class="muted">Visual: ${esc(s.visualPrompt)}</p></div>`).join('')}<button class="primary" onclick="render('${p.id}')">🎬 Render demo video</button><div id="renderStatus"></div></div>`;
}
async function render(id){$('#renderStatus').textContent='Rendering…';const r=await fetch('/api/render/'+id,{method:'POST'});const p=await r.json();$('#renderStatus').innerHTML=p.error?`<p>${esc(p.error)}</p>`:`<p>Done! <a href="${p.rendered}" target="_blank">Open rendered video</a></p>`;}
async function loadProjects(){const r=await fetch('/api/projects');const ps=await r.json();$('#projectList').innerHTML=ps.length?ps.map(p=>`<div class="project"><b>${esc(p.title)}</b><div class="muted">${new Date(p.createdAt).toLocaleString()} · ${p.platform}</div></div>`).join(''):'<div class="card">No projects yet. Your first one is waiting for you. 👀</div>';}
function esc(x){return String(x).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
