const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const { generateProject } = require("./server/providers");
const { renderVideo } = require("./server/render");

const app = express();
app.use(cors());
app.use(express.json({limit:"10mb"}));
app.use(express.static(path.join(__dirname, "public")));

const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
const projectsFile = path.join(dataDir, "projects.json");
if (!fs.existsSync(projectsFile)) fs.writeFileSync(projectsFile, "[]");

function loadProjects(){ return JSON.parse(fs.readFileSync(projectsFile)); }
function saveProjects(p){ fs.writeFileSync(projectsFile, JSON.stringify(p,null,2)); }

app.get("/api/projects", (req,res)=>res.json(loadProjects()));

app.post("/api/generate", async (req,res)=>{
  try {
    const {topic, style="viral facts", platform="tiktok", duration=45} = req.body;
    if(!topic?.trim()) return res.status(400).json({error:"Topic is required"});
    const project = await generateProject({topic,style,platform,duration});
    const projects = loadProjects();
    projects.unshift(project);
    saveProjects(projects);
    res.json(project);
  } catch(e){ res.status(500).json({error:e.message}); }
});

app.post("/api/render/:id", async (req,res)=>{
  try {
    const project = loadProjects().find(p=>p.id===req.params.id);
    if(!project) return res.status(404).json({error:"Project not found"});
    const output = await renderVideo(project);
    project.rendered = output;
    const projects = loadProjects().map(p=>p.id===project.id?project:p);
    saveProjects(projects);
    res.json(project);
  } catch(e){ res.status(500).json({error:e.message}); }
});

app.get("/api/health",(req,res)=>res.json({ok:true, service:"AI Video Studio", version:"1.0.0"}));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log(`AI Video Studio running on http://localhost:${process.env.PORT||3000}`));
