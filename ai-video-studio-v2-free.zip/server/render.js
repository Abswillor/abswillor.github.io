const fs = require("fs");
const path = require("path");
const {spawn} = require("child_process");

function renderVideo(project){
  return new Promise((resolve,reject)=>{
    const outDir = path.join(__dirname,"..","renders");
    if(!fs.existsSync(outDir)) fs.mkdirSync(outDir);
    const out = path.join(outDir, `${project.id}.mp4`);
    // Creates a clean, shareable demo video from generated scene cards.
    // Swap the input generation stage for AI images/video + TTS later.
    const text = project.scenes.map((s,i)=>`${i+1}. ${s.caption}`).join("  •  ");
    const safe = text.replace(/:/g,"\\:").replace(/'/g,"\\'");
    const args = [
      "-y","-f","lavfi","-i",`color=c=black:s=1080x1920:r=30`,
      "-t",String(project.duration),
      "-vf",`drawtext=text='${safe.slice(0,900)}':fontcolor=white:fontsize=48:x=(w-text_w)/2:y=(h-text_h)/2:line_spacing=18`,
      "-c:v","libx264","-pix_fmt","yuv420p","-movflags","+faststart",out
    ];
    const p=spawn("ffmpeg",args);
    let err="";
    p.stderr.on("data",d=>err+=d.toString());
    p.on("close",code=>{
      if(code!==0) return reject(new Error("FFmpeg render failed. Is FFmpeg installed?\n"+err.slice(-1500)));
      resolve(`/renders/${path.basename(out)}`);
    });
  });
}
module.exports={renderVideo};
