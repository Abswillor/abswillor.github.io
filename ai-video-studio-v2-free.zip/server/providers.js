const crypto = require("crypto");

const hooks = [
  "You won't believe what happens when you discover this.",
  "Most people have no idea about this.",
  "Here are the facts nobody tells you.",
  "Wait until you hear the last one."
];

function cleanTopic(topic){ return topic.trim().replace(/\s+/g," "); }

async function generateProject({topic,style,platform,duration}){
  // Provider abstraction: replace this demo implementation with your preferred
  // text/image/video/voice APIs later without changing the frontend.
  const t = cleanTopic(topic);
  const count = Math.max(4, Math.min(8, Math.round(duration/8)));
  const scenes = [];
  const hook = hooks[Math.floor(Math.random()*hooks.length)];
  for(let i=0;i<count;i++){
    scenes.push({
      id: crypto.randomUUID(),
      seconds: i===0 ? 5 : Math.max(4, Math.round((duration-5)/(count-1))),
      narration: i===0
        ? `${hook} Today we're breaking down ${t}.`
        : `Point ${i}: here's an interesting thing to know about ${t}. The key takeaway is simple, useful, and worth remembering.`,
      visualPrompt: `Cinematic, high-retention social video visual about ${t}, scene ${i+1}, natural lighting, realistic detail, vertical composition, no text`,
      caption: i===0 ? hook : `Point ${i}: ${t}`
    });
  }
  return {
    id: crypto.randomUUID(),
    title: `${t} — ${style}`,
    topic:t, style, platform, duration:Number(duration),
    createdAt:new Date().toISOString(),
    status:"planned",
    scenes
  };
}

module.exports = {generateProject};
