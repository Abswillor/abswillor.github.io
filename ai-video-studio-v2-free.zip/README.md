# AI Video Studio — V2 (free demo build)

This is the first phone-friendly build of your AI video factory.

## What works without paid AI APIs
- Create a project from a topic
- Choose content style
- Choose TikTok/Shorts or YouTube
- Automatic script/scene planning in demo mode
- Project library
- Video rendering through FFmpeg
- Browser dashboard

## Run on a computer
1. Install Node.js 24 LTS and FFmpeg.
2. `npm install`
3. `node server.js`
4. Open http://localhost:3000

## Run from Android with GitHub Codespaces
1. Create a GitHub account.
2. Create a new repository.
3. Upload this project folder.
4. Open the repository → Code → Codespaces → Create codespace on main.
5. Wait for the browser editor to open and dependencies to install.
6. In the terminal run: `node server.js`
7. Open the forwarded port 3000 shown by Codespaces.

The included `.devcontainer/devcontainer.json` installs Node and FFmpeg automatically in the Codespace.

## Important
This version is intentionally free/demo. It does not call a paid AI API.
The provider layer is isolated in `server/providers.js`, so OpenAI or another provider can be connected later without rebuilding the whole frontend.
